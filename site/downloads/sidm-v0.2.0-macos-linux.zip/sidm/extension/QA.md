# Extension QA checklist

Manual checks, grouped by milestone. Tick each before calling a milestone done.

## M1 Skeleton

- [ ] `chrome://extensions` > Load unpacked > `extension/` loads with no error or warning on the card.
- [ ] The card shows ID `ejkhmcfjnohjikdgfgkhjficmiaoghma`. Remove and load again: the ID stays the same.
- [ ] "Service worker" link on the card opens DevTools with no errors in the console.
- [ ] The toolbar icon is a purple rounded square with a white down-arrow and mint line, sharp at 100% and 150% scaling.
- [ ] Popup opens, shows "Downloads" and "This page" tabs; switching works; reopening remembers the last tab.
- [ ] The sliders button in the popup opens the settings page in a new tab.
- [ ] Settings: Language = বাংলা switches the settings page and the popup to Bangla right away; Automatic follows the browser language.
- [ ] Settings: Theme = Dark / Light / Automatic switches immediately; Automatic follows Windows dark mode.
- [ ] Settings: About shows the version and the extension ID.
- [ ] Same checks in Edge and Brave.

## Update available (release tooling, Step 4)

Needs `SITE_URL` set in `extension/update-check.js` and a `version.json` reachable there.

- [ ] With `version.json` showing a **higher** version than the manifest, the popup footer shows "Update available" (Bangla: "আপডেট পাওয়া যাচ্ছে"); clicking it opens the website in a new tab.
- [ ] With the **same or lower** version, or the site offline, no footer link and no console error.
- [ ] Open the popup several times: DevTools Network shows at most one `version.json` request per 24 hours.
- [ ] With `SITE_URL` empty, no request is made at all.

## M2 Download list

- [ ] Start a few downloads from any site: the "Downloads" tab lists every Chrome download, newest first, including ones started before the popup opened.
- [ ] A running download shows name, progress bar, "x of y", speed and time left. The speed settles within a few seconds and does not jump around.
- [ ] A server without a size (no Content-Length) shows a moving bar and the bytes received.
- [ ] Toolbar badge = number of running downloads; pausing one lowers it, finishing all clears it.
- [ ] Pause / Resume / Cancel work from the row. Cancelled rows are struck through.
- [ ] Retry on a failed or cancelled download: resumes if Chrome can, otherwise starts the same URL again and the old row goes away.
- [ ] Completed rows: Open file opens it, Show in folder opens Explorer with the file selected. If the file was deleted on disk, the row says "File deleted".
- [ ] Copy link puts the URL on the clipboard and shows "Link copied".
- [ ] Remove from list removes the row but keeps the file on disk.
- [ ] Search matches the file name and the URL. Each category chip (Video, Music, Documents, Programs, Archives, Images, Other) shows only that type; "All" shows everything; no match shows "No downloads match".
- [ ] "Clear finished" removes every row that is not running or paused, and hides itself when there is nothing to clear.
- [ ] While a download runs, open DevTools on the popup (right-click > Inspect), Elements panel: rows flash only in the changed fields; the list is not rebuilt.
- [ ] Switch Settings to বাংলা and Dark while the popup is open: chips, states and buttons switch at once.

## M3 Folder sorting + queue

- [ ] Download a PDF, an MP4, a ZIP and an EXE from any site: they land in `Downloads/SIDM/Documents`, `/Video`, `/Archives`, `/Programs`. A file with an unknown extension goes to `/Other` (or by its MIME type).
- [ ] Settings > folder sorting off (M8, or `chrome.storage.sync.set({sortIntoFolders:false})` in the service worker console): new downloads go straight to `Downloads/` again.
- [ ] A second download with the same name gets ` (1)` added; nothing is overwritten.
- [ ] Set max simultaneous to 2 and add 4 large links in the "+" panel (M4): 2 run, 2 show "Waiting in queue". Pausing one starts the next. Cancelling a waiting row removes it.
- [ ] Close and reopen the browser with items waiting: they start again.
- [ ] Names we choose are made safe for Windows: `a:b?.pdf` saves as `a_b_.pdf`, `CON.txt` as `_CON.txt`, a 300-character name is cut to 150 with the extension kept, and a Bangla name (`বাংলা গান.mp3`) is kept as is.
- [ ] Notifications (on by default): a finished download shows "Download complete"; clicking it opens the folder. A failed one shows "Download failed" with the reason. Cancelling shows nothing.

## M4 Add links + context menus

- [ ] Popup "+" opens the add panel. Paste 3 lines: two https links and `ftp://x`. "Add" queues the two and says "Added 2 to the queue · 1 skipped (not http/https)". Duplicate lines are added once. Ctrl+Enter adds, Esc closes.
- [ ] Add with an empty box: "Paste at least one http:// or https:// link." and nothing is queued.
- [ ] Right-click a link > "Download link with SIDM": it goes through the queue and into the sorted folder.
- [ ] Right-click an image, and a `<video>`/`<audio>` element with a real `src` > "Download this file with SIDM".
- [ ] Right-click an image whose address is `blob:` or `data:` (for example a canvas export) > a notification explains it cannot be saved, nothing is queued.
- [ ] Right-click the page background > "Grab all links on this page" opens the link grabber (M5) in a tab next to it.
- [ ] Switch the language to Bangla: the menu entries switch to Bangla.

## M5 Link grabber

- [ ] On a page with many links (a file index or a download site), right-click > "Grab all links on this page": a tab opens next to it with a table (checkbox, name, type, address) and chips with counts per category.
- [ ] Links inside iframes are included. The same URL appears once. `mailto:`, `javascript:` and `#` links are not listed.
- [ ] Typing in the filter narrows by name, address or link text; chips narrow by category; the header checkbox selects every row shown (and only those).
- [ ] "Download selected" queues the selected rows (watch the popup: max simultaneous is respected) and clears the ticks.
- [ ] Close the source tab, then press "Scan again": "The tab is gone".
- [ ] On `chrome://settings` and on the Chrome Web Store, "Grab all links" shows "Chrome does not allow this page".
- [ ] On a page with no links: "No links found".

## M6 Media detection ("This page")

- [ ] Open a page that plays a plain MP4 or MP3 (for example a file on a test server or a site that uses `<video src="...mp4">`): the toolbar icon shows a green number on that tab, and "This page" lists the file with size and type. "Download" queues it with the shown name.
- [ ] HLS/DASH players (`.m3u8`, `.mpd`, `.ts`, `.m4s`) are not listed; only whole files are.
- [ ] Files smaller than the minimum size (default 200 KB) are not listed.
- [ ] A response with `Content-Disposition: attachment; filename*=UTF-8''...` is listed under that (decoded) name. Without a usable name, the tab title plus an extension from the MIME type is used.
- [ ] At most 25 entries per tab; navigating the tab to a new page clears the list and the green badge. Other tabs keep their own lists.
- [ ] On YouTube nothing is detected and "This page" says detection is always off there.
- [ ] On Netflix, Prime Video, Disney+, Spotify and similar, nothing is detected and "This page" says SIDM does not download from DRM services.
- [ ] Add a site to "Disabled sites" in Settings (M8): nothing is detected there and "This page" says so.
- [ ] With no media, the tab shows "Nothing found on this page", and the global badge (number of running downloads) shows instead of the green one.

## M7 Companion bridge (video sites)

Needs the companion installed (`companion/install.bat` on Windows).

- [ ] On a video page of facebook.com, fb.watch, x.com, twitter.com, instagram.com, tiktok.com, vimeo.com, dailymotion.com, reddit.com, twitch.tv, vk.com, ok.ru, bilibili.com or streamable.com, "This page" shows the "Video on this page" card: companion status, quality (Best, 1080p, 720p, 480p, 360p, Audio only) and "Download video".
- [ ] Status shows "Companion app 0.x connected" with a green dot. Uninstall the companion and reopen the popup: "not installed" with help text, and the button is disabled.
- [ ] "Download video": a row appears under "Video downloads" with bar, size, speed and time left; when done it says "Saved" and the folder button opens the folder in a tab. A note from the companion (for example ffmpeg missing) shows in italics.
- [ ] Cancel a running video: "Cancelled"; Retry starts it again; Remove clears finished rows.
- [ ] End the companion process (Task Manager) during a download: the row turns "Failed: The companion app stopped"; the next "Download video" reconnects.
- [ ] Right-click on a page of those sites > "Download video from this page with SIDM" starts a job at the default quality. Without the companion, a notification explains how to install it.
- [ ] YouTube: no card controls, only the note that YouTube downloads are off; no context-menu entry. After turning on "Allow YouTube" in Settings (M8), the card and the menu appear on youtube.com.
- [ ] Netflix and other DRM sites: no card, no menu; asking the worker for addVideo there returns the DRM refusal.
- [ ] Leave the browser idle for a minute with no video running: the companion process exits (no zombie host).

## M8 Settings page

- [ ] Every control saves as soon as it changes ("Saved" toast) and is still set after closing and reopening Settings, and on another computer signed in to the same browser profile (storage.sync).
- [ ] Language Automatic / English / বাংলা and Theme Automatic / Light / Dark apply at once to Settings and an open popup.
- [ ] Sort into folders off: new downloads go to plain `Downloads/`.
- [ ] Downloads at the same time: typing 25 saves 10, typing 0 saves 1.
- [ ] Ask where to save on: links added with "+" open the Save As window.
- [ ] Notifications off: no finish/fail notifications (the blob:/data: explanation still shows).
- [ ] Media detection off: "This page" says it is off and nothing is listed; minimum size 1000 KB hides smaller files.
- [ ] Disabled sites: `https://www.Example.com/path` is saved as `example.com`; entries without a dot are dropped; duplicates are removed.
- [ ] Companion line shows connected with the yt-dlp / ffmpeg versions and the save folder, or "not installed" with help text.
- [ ] Default video quality is used by the right-click video menu and preselected in the popup card.
- [ ] Allow YouTube: clicking the switch opens the Terms of Service warning. Cancel leaves it off; "I understand, turn it on" turns it on. Turning it off needs no warning.

## M9 Release checks (0.1.0)

Run `python scripts/test_extension.py` first (all PASS), then by hand:

- [ ] **Service worker asleep:** on `chrome://extensions` > SIDM > "Service worker", wait 5 minutes until it shows "inactive". Then: start a download from a site (it is sorted into a folder), right-click a link > "Download link with SIDM" (it starts), open a page with a video (green badge appears), open the popup (list correct). Each wakes the worker with no error on the card.
- [ ] **Queue after sleep:** with max 1, add 3 links, let the worker sleep, then cancel the running one: the next queued link starts.
- [ ] **Incognito:** turn on "Allow in Incognito" for SIDM. Downloads from an incognito window appear in the popup opened there, are sorted, and media detection works. The popup in a normal window does not list incognito downloads.
- [ ] **Alt-click:** Alt+click on a link (Chrome's own "download link" shortcut) downloads it directly without the queue; it still appears in the list and is sorted into a folder.
- [ ] **chrome:// pages:** on `chrome://settings`, `edge://settings` and the Web Store: the popup opens without errors, "This page" shows "Nothing found", "Grab all links" says Chrome does not allow the page.
- [ ] **Dark mode:** set Windows to dark mode with Theme = Automatic: popup, settings and grabber are dark with readable text, badges and type tiles. Theme = Light overrides it.
- [ ] **Bangla UI:** Language = বাংলা: popup, settings, grabber, context menus and notifications are in Bangla with no English left except file names, sizes and product names; long Bangla labels do not overflow.
- [ ] **Edge and Brave:** Load unpacked works and the ID is the same.
- [ ] Version in Settings > About is 0.1.0.

## M10 Download button on videos

- [ ] On a page with a plain `<video>` (for example a free stock-video site), move the pointer over the video: a "Download" pill appears at its top-right corner and fades after 2.5 s without movement. Small videos (under 200×112) get no button.
- [ ] Click it: the menu lists the files the page played (with size and type) and the video's own file. Choosing one adds it to the queue and shows "Added to SIDM".
- [ ] On a supported video site (Facebook, X, Vimeo...), the menu also offers "Download video" through the companion at the default quality.
- [ ] If nothing is known yet: "Nothing to download yet. Play the video for a few seconds, then try again."
- [ ] No button on YouTube (unless Allow YouTube is on, then only the companion entry), on Netflix/other DRM sites, on disabled sites, or when "Download button on videos" is off in Settings.
- [ ] The page's own styles do not change the button; clicking elsewhere closes the menu; the page keeps working (play/pause clicks still reach the player).
- [ ] Bangla UI: the button and menu are in Bangla.

## M11 Progress window

- [ ] Add a large file with the "+" panel: a small window opens with the file name, a progress bar with percent, and the Status tab (address, status, file size, downloaded with percent, transfer rate, time left, can resume, saved to).
- [ ] "Can resume" shows "Checking…" and then "Yes" for a normal file server, "No" for a server without Range support.
- [ ] Pause, Resume and Cancel in the window act on the download, and the popup list follows.
- [ ] "Hide details" shrinks the window to the name, bar and buttons; "Show details" brings them back.
- [ ] In the popup, the details button of a running row opens the window; clicking it again focuses the same window instead of opening another.
- [ ] When finished: with "Show the file in its folder" on, the folder opens when the download completes; with "Close this window" on, the window closes. With both off, the window stays with Open file / Show in folder / Close.
- [ ] Settings > Downloads > Progress window: "Never" opens no window, "For every download" also opens one for downloads you start in Chrome itself.
- [ ] Add 10 links at once: at most 3 windows open in 10 seconds.
- [ ] Remove the download from the list while its window is open: "This download is gone".
- [ ] Dark theme and Bangla look right; the window title shows the percent.

## M12 Download manager page

- [ ] Popup header: the manager button opens the manager in a tab; clicking it again focuses that tab.
- [ ] The left tree shows All (with the file categories under it), Unfinished, Finished and Queue, each with a live count. Clicking one filters the table.
- [ ] Table columns: file name, size, status (with percent and a bar while running), time left, transfer rate, last try, address. Clicking a column header sorts, clicking again reverses.
- [ ] Selection: click, Ctrl/Cmd-click, Shift-click, Ctrl+A, Esc. Double-click or Enter opens a finished file, or the progress window of a running one.
- [ ] Toolbar: Add URL opens the links box; Resume and Stop act on the selected rows and are greyed out when they cannot; Stop all pauses everything and stops the queue so nothing new starts.
- [ ] Delete asks first; "Also delete the finished files from the disk" is off by default and only removes files of finished downloads. Delete completed clears finished rows from the list and keeps the files.
- [ ] Stop queue: waiting items stay waiting even when slots are free; the status bar says "Queue stopped". Start queue starts them.
- [ ] Grabber opens the grabber for the active web tab, or explains that a web page must be open first. Settings opens the settings page.
- [ ] The status bar shows items, selected, total speed and waiting items. Dark theme and Bangla look right.

## M13 Multi-connection downloads (companion)

Needs the companion installed (install.bat).

- [ ] Settings > Downloads: "Multi-connection downloads" is on, "Connections per download" is 8 (1 to 16).
- [ ] Add a big file (50 MB or more) from a normal file server: it downloads through the companion. The progress window shows "Connections 8 of 8", a bar with one block per part, and a table of parts that fill up. Speed is clearly higher than a browser download on a server that limits speed per connection.
- [ ] The file lands in `Downloads\SIDM\<Category>\` with a `.gsdmpart` file while it runs and only the final file afterwards.
- [ ] Pause, then Resume: it continues from where it stopped (the downloaded amount does not go back to 0). Close the browser while paused, start it again, Resume: it still continues.
- [ ] Cancel: the `.gsdmpart` and `.gsdmpart.json` files are removed, nothing else in the folder changes.
- [ ] Open file and Show in folder work for a finished companion download (popup, manager, progress window).
- [ ] Speed limit tab: turn the limit on at 300 KB/s: the rate drops to about 300 KB/s within a few seconds; turn it off: it goes back up.
- [ ] Small files (under 1 MB), servers that do not support ranges, links that need a login, and "Ask where to save" all use the browser download as before.
- [ ] Without the companion installed, everything uses the browser and nothing shows an error.
- [ ] The toolbar badge counts companion downloads too; the queue limit counts them as running.

## M14 Speed limit, scheduler, when the queue is done

- [ ] Settings > Downloads > Speed limit 300 KB/s: companion downloads run at about 300 KB/s; 0 removes the limit. The hint says browser downloads cannot be limited.
- [ ] Settings > Scheduler: turn on, start 2 minutes from now, no stop time, today ticked. Stop the queue in the manager and add 3 links: nothing starts. At the start time the queue starts, and downloads paused with "Stop all" carry on.
- [ ] With a stop time set: at that time running downloads pause and the queue stops.
- [ ] Untick today: nothing happens at the start time. Turn the schedule off: nothing happens.
- [ ] The manager's Scheduler button opens Settings at the Scheduler section.
- [ ] When the queue is done = "Show a notification": after the last waiting download finishes, a "Queue finished" notification appears (once). "Close the browser" closes every browser window. Paused downloads keep the queue from counting as done.
- [ ] Bangla day names and labels; dark theme.

## YouTube on by default; videos in feeds

- [ ] Fresh install: Settings > Video sites > "Allow YouTube downloads" is on.
- [ ] On a YouTube watch page, the popup's video card offers Download video; the first YouTube download shows the one-time notice "About downloading from YouTube"; later ones do not.
- [ ] The Download button over the YouTube player offers "Download video" through the companion.
- [ ] Turn YouTube off: no button on YouTube, the card says it is off, the right-click entry is gone. Turning it on again shows the warning dialog.
- [ ] Facebook and X feeds: the Download button over a video in the feed downloads that post's video (its own /videos/, /reel/ or /status/ address), not the feed page.
- [ ] Netflix, Prime Video, Disney+, Spotify: no button, and video downloads are refused.

## Video button on any site (fix after real-browser feedback)

Real sites cannot be reached from the build machine, so these need a real Chrome on Windows with the companion installed. For each site, play a video and hover it:

- [ ] **X / Twitter** (home feed and a single post): the Download button appears; the menu lists Best, 1080p, 720p, 480p, 360p, Audio only; Best downloads that post's video.
- [ ] **LinkedIn** feed video: same.
- [ ] **Facebook** feed video and a Reel: same; the download is that post's video, not the feed.
- [ ] **Instagram** post or Reel, **TikTok**, **YouTube** (watch page and Shorts), **Vimeo**, **Reddit**, **Pinterest**: same.
- [ ] A site not on the list that plays a video: the menu says "Try with the companion app" with the same qualities. Some sites will fail; the job then shows the companion's error.
- [ ] Without the companion installed: the menu says to install it (install.bat) and "How to install it" opens Settings at the companion status.
- [ ] Tabs that were already open when the extension was installed or updated get the button without reloading.
- [ ] Right-click on any video: "Download video from this page" sends it to the companion.
- [ ] Netflix, Prime Video, Disney+, Spotify: no button.

